# Spotify-Lyric-Translating-Visualizer
Translate and visualize song lyrics from spotify
